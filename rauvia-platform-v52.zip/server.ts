import 'dotenv/config';
import express from 'express';
import path from 'path';
import fs from 'fs';
import { randomUUID } from 'node:crypto';
import { publicRoutes } from './scripts/public-routes.js';
import { fetchPosts, renderSitemap } from './scripts/generate-sitemap.js';
import { GoogleGenAI } from '@google/genai';
import { ASSISTANT_SYSTEM_PROMPT } from './server/prompts/assistant';
import { FALLBACK_POSTS } from './src/data/fallbackPosts';
import { testConnection, isDbConfigured, closeDbPool } from './server/db';
import { handleTrackEvent } from './server/analytics/events';
import { aiCrawlerMiddleware } from './server/analytics/crawlerMiddleware';
import { logEvent, serializeError } from './server/logger';
import { beginTrackedTask, startObservabilityTicker, stopObservabilityTicker } from './server/observability/index.js';
import { attachInboundHttpSocketTracking, destroyAllInboundHttpSockets } from './server/observability/runtime.js';
import { getSafeUrlMeta } from './server/observability/redaction.js';
import { withRequestContext } from './server/observability/context.js';

let cachedPosts: any[] = FALLBACK_POSTS;
let lastFetchTime = 0;
const CACHE_TTL = 10 * 60 * 1000; // 10 minutes cache

async function fetchWPPosts(slug?: string) {
  // Return from in-memory cache if valid to avoid hitting WP too frequently
  if (Date.now() - lastFetchTime < CACHE_TTL && cachedPosts !== FALLBACK_POSTS) {
    if (slug) {
      const match = cachedPosts.find((p: any) => p.slug === slug);
      if (match) return [match];
      // If not found in cache, proceed to fetch
    } else {
      return cachedPosts;
    }
  }

  const wpBase = process.env.VITE_WORDPRESS_API_URL || 'https://blog.rauvia.com.mx/wp-json/wp/v2';
  // Workaround de infraestructura (Hostinger):
  // Obliga a tratar cada consulta REST como una URL nueva para evitar respuestas vacías del CDN.
  // Si posteriormente se comprueba que WP REST responde correctamente sin él, puede eliminarse.
  const cacheBuster = `_cb=${Date.now()}`;
  const wpUrl = slug
    ? `${wpBase}/posts?slug=${encodeURIComponent(slug)}&_embed&status=publish&${cacheBuster}`
    : `${wpBase}/posts?_embed&status=publish&${cacheBuster}`;

  try {
    console.log(`[fetchWPPosts] Fetching: ${wpUrl}`);
    let data;
    // Reducimos reintentos y usamos timeout corto para evitar bloqueos bajo carga
    for (let i = 0; i < 2; i++) {
      try {
        const timeoutMs = Number(process.env.WORDPRESS_FETCH_TIMEOUT_MS) || 5000;
        const wpRes = await fetch(wpUrl, { signal: AbortSignal.timeout(timeoutMs) });
        if (wpRes.ok) {
          data = await wpRes.json();
          break;
        } else {
          console.error(`[fetchWPPosts] HTTP Error: ${wpRes.status} ${wpRes.statusText}`);
          if (i === 1) throw new Error(`HTTP ${wpRes.status}`);
        }
      } catch (err) {
        if (i === 1) throw err;
        await new Promise(r => setTimeout(r, 500)); // retry backoff rápido
      }
    }

    console.log(`[fetchWPPosts] Success. Received ${data?.length || 0} posts.`);
    if (Array.isArray(data) && data.length > 0) {
      if (!slug) {
        cachedPosts = data;
        lastFetchTime = Date.now();
      }
      return data;
    }
  } catch (err: any) {
    console.error(`[fetchWPPosts] Fetch Exception:`, err.message);
  }

  // Fallback to cache or hardcoded fallback
  if (slug) {
    const match = cachedPosts.find((p: any) => p.slug === slug);
    return match ? [match] : [];
  }
  return cachedPosts;
}

async function startServer() {
  const app = express();

  // === REDIRECCIONES SEO 301 PERMANENTES ===
  app.use((req, res, next) => {
    // Limpieza de trailing slash para normalizar la comparación de rutas
    const normalizedPath = req.path.endsWith('/') && req.path.length > 1 
      ? req.path.slice(0, -1) 
      : req.path;

    // Redirección de subdominio (Si el DNS/Hostinger enruta 'shop' hacia esta instancia Node)
    if (req.hostname === 'shop.rauvia.com.mx') {
      return res.redirect(301, 'https://rauvia.com.mx/');
    }
    
    // Rutas antiguas hacia nuevas ubicaciones (conservando Link Equity)
    if (normalizedPath === '/blog' || normalizedPath.startsWith('/blog/')) {
      return res.redirect(301, '/recursos/');
    }
    
    if (normalizedPath === '/servicios' || normalizedPath.startsWith('/servicios/')) {
      return res.redirect(301, '/soluciones/');
    }

    // Redirecciones de artículos antiguos hacia /recursos/
    const oldArticles = [
      '/delegacion-hueca-caos-a-sistema-90-dias',
      '/componentes-ruta-90-dias-pymes',
      '/analisis-estrategico-mensual-startup'
    ];
    
    if (oldArticles.includes(normalizedPath)) {
      return res.redirect(301, '/recursos/');
    }
    
    next();
  });
  // =========================================

  // Serve public machine-readable references before the SPA fallback, in both modes.
  const isProd = process.env.NODE_ENV === 'production' || !process.env.NODE_ENV;
  const discoveryRoot = path.join(process.cwd(), isProd ? 'dist' : 'public');
  app.get('/llmo', (_req, res) => res.redirect(302, '/llmo/index.json'));
  app.use('/llmo', express.static(path.join(discoveryRoot, 'llmo'), {
    index: false,
    setHeaders: (res, filePath) => {
      if (filePath.endsWith('.md')) res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
      res.setHeader('X-Content-Type-Options', 'nosniff');
    },
  }), (_req, res) => { res.status(404).type('text/plain').send('Not found'); });
  const PORT = Number(process.env.PORT) || 3000;

  // Inyectar Request ID y contexto de observabilidad
  app.use((req, res, next) => {
    const requestId = (req.headers['x-request-id'] as string) || randomUUID();
    res.setHeader('x-request-id', requestId);
    withRequestContext({ requestId, startedAtMs: Date.now() }, next);
  });

  // Limitar el tamaño del body a 1MB para prevenir ataques DoS por payloads gigantes
  app.use(express.json({ limit: '1mb' }));
  startObservabilityTicker();

  const createHttpTask = (req: express.Request, res: express.Response, taskName: string) => {
    let aborted = false;
    res.once('close', () => { if (!res.writableEnded) aborted = true; });
    const task = beginTrackedTask(taskName, 'incoming_http_request', { method: req.method, path: req.path, resource: 'incoming_http_request' });
    return { finish(error: unknown = null, meta: Record<string, unknown> = {}) {
      if (aborted) task.abort({ statusCode: res.statusCode, ...meta });
      else if (error) task.fail({ statusCode: res.statusCode, error: serializeError(error), ...meta });
      else task.complete({ statusCode: res.statusCode, ...meta });
    }};
  };

  // ==========================================
  // DOMAIN CANONICALIZATION & REDIRECTS
  // ==========================================
  app.use((req, res, next) => {
    const host = req.hostname || '';
    
    // Check if the request is coming from a non-canonical domain
    const isNonCanonical = 
      host === 'www.rauvia.com.mx' ||
      host === 'rauvia.consulting' ||
      host === 'www.rauvia.consulting';

    if (isNonCanonical) {
      // Reconstruct the URL with the canonical domain, preserving path and query string (UTMs)
      const canonicalUrl = `https://rauvia.com.mx${req.originalUrl}`;
      return res.redirect(301, canonicalUrl);
    }

    // Trailing Slash Enforcer for SEO
    // Force a trailing slash on non-file GET requests (except /api/, /llmo, etc.)
    if (req.method === 'GET' && !req.path.endsWith('/') && !path.extname(req.path)) {
      if (!req.path.startsWith('/api') && !req.path.startsWith('/llmo')) {
        const query = req.url.slice(req.path.length);
        return res.redirect(301, `${req.path}/${query}`);
      }
    }
    
    next();
  });

  // AI Crawler Analytics Middleware
  app.use(aiCrawlerMiddleware);

  // Legacy URLs that should return 410 Gone (no equivalent content yet)
  const LEGACY_GONE_PATHS = new Set([
    '/componentes-ruta-90-dias-pymes',
    '/analisis-estrategico-mensual-startup',
    '/metricas-de-rentabilidad-para-agencias-en-cdmx',
    '/test-madurez-sistemica',
    '/wp-content/uploads/2025/11/RAUVIA_PRESENTACION_GUIA_2025.pdf',
    // Otras URLs que no tienen reemplazo
    '/sobre-rauvia',
    '/servicios',
    '/contacto',
    '/nuestro-metodo',
    '/consultoria_gratis',
    '/test-madurez-sistemica',
    '/blog',
    '/blindaje-operativo-2026',
    '/delegacion-hueca-caos-a-sistema-90-dias',
    '/metricas-de-rentabilidad-para-agencias-en-cdmx',
    '/guia-gobernanza-rauvia',
    '/claridad-operativa-el-regalo-que-si-negocio-necesita',
    '/ruta-90-dias-agencias',
    '/diagnostico-de-fuga-de-capital-mejora-la-eficiencia-en-tu-agencia',
    '/ejecucion-ruta-90-solo-vs-acompanamiento',
    '/que-hace-rauvia-ruta-90-dias',
    '/ia-estrategia-contenido-agencias',
    '/wp-content/uploads/2025/11/RAUVIA_PRESENTACION_GUIA_2025.pdf',
    '/contacto-anterior',
    '/servicios-antiguos',
    '/acerca-de',
  ]);

  // Regex patterns for other historical URLs to mark as Gone
  const LEGACY_GONE_PATTERNS = [
    /^\/ruta-90\//,
    /^\/diagnostico-/,
    /^\/growth-partner\//,
    /^\/blueprint-/,
    /^\/frente-comercial-esencial\//,
    /^\/servicios\//
  ];

  // Historical legacy 301 redirects to valid equivalents
  const LEGACY_REDIRECT_PATHS = new Map([
    ['/blog', '/recursos']
  ]);

  app.use((req, res, next) => {
    let pathName = req.path;
    if (pathName.length > 1 && pathName.endsWith('/')) {
      pathName = pathName.slice(0, -1);
    }

    // 1. Mark as 410 Gone if it's in the exact list or matches a pattern
    if (LEGACY_GONE_PATHS.has(pathName) || LEGACY_GONE_PATTERNS.some(regex => regex.test(pathName))) {
      return res.status(410).type('text/html').send('<!DOCTYPE html><html><head><title>Página no disponible (410) | RAUVIA</title></head><body><h1>410 - Contenido retirado</h1><p>El contenido que buscas ya no forma parte de la oferta o metodología actual de RAUVIA.</p><a href="/">Volver al inicio</a></body></html>');
    }

    // 2. Redirect 301 for known equivalents
    if (LEGACY_REDIRECT_PATHS.has(pathName)) {
      return res.redirect(301, LEGACY_REDIRECT_PATHS.get(pathName)!);
    }

    next();
  });

  // WP Posts Proxy Route
  app.get('/api/wp/posts', async (req, res) => {
    const request = createHttpTask(req, res, 'api_wp_posts_request'); let error: unknown = null;
    try { const slug = req.query.slug as string | undefined; const posts = await fetchWPPosts(slug); res.json(posts); }
    catch (err) { error = err; throw err; }
    finally { request.finish(error); }
  });

  // Analytics Tracking Endpoint
  app.post('/api/events', async (req, res) => {
    const request = createHttpTask(req, res, 'api_events_request'); let error: unknown = null;
    try { await handleTrackEvent(req, res); }
    catch (err) { error = err; throw err; }
    finally { request.finish(error); }
  });

  // LLM / LLMO API Endpoint
  // Prepared for Gemini API integration with RAUVIA context
  app.post('/api/llm', async (req, res) => {
    const request = createHttpTask(req, res, 'api_llm_request'); let error: unknown = null;
    try {
      const { messages } = req.body;
      
      if (!messages || !Array.isArray(messages)) {
        return res.status(400).json({ error: 'La carga útil debe incluir un array de messages.' });
      }

      if (!process.env.GEMINI_API_KEY) {
        return res.status(500).json({ error: 'GEMINI_API_KEY no está configurada en el servidor.' });
      }

      const ai = new GoogleGenAI({ 
        apiKey: process.env.GEMINI_API_KEY,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      // Map format from { role: 'user'|'assistant', content: string } to Gemini format
      const formattedMessages = messages.map(msg => ({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }]
      }));

      // Wrap the Gemini API call in a Promise.race to enforce a 30-second timeout
      const geminiTask = beginTrackedTask('gemini_generate_content', 'external_http_request', {
        externalService: 'gemini', resource: 'external_http_request', model: 'gemini-3.8-flash'
      });
      let geminiError: unknown = null; let response: any;
      try {
        const generatePromise = ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: formattedMessages,
          config: {
            systemInstruction: ASSISTANT_SYSTEM_PROMPT,
          }
        });

        const timeoutPromise = new Promise((_, reject) => 
          setTimeout(() => reject(new Error('Gemini API Timeout exceeded 30000ms')), 30000)
        );

        response = await Promise.race([generatePromise, timeoutPromise]) as any;
      } catch (err) { geminiError = err; throw err; }
      finally { if (geminiError) geminiTask.fail({ error: serializeError(geminiError) }); else geminiTask.complete({ statusCode: 200 }); }

      res.json({
        status: "success",
        response: response.text
      });
    } catch (err: any) {
      error = err;
      console.error('LLM API Error:', err);
      if (err.message && err.message.includes('Timeout')) {
        return res.status(504).json({ error: 'Timeout al conectar con Gemini API' });
      }
      res.status(500).json({ error: 'Internal Server Error al conectar con Gemini API' });
    } finally {
      request.finish(error);
    }
  });

  // MySQL Database Health Check Endpoint (never exposes password/secrets)
  app.get('/api/db/health', async (req, res) => {
    try {
      const status = await testConnection();
      if (!status.connected) {
        return res.status(503).json(status);
      }
      return res.json(status);
    } catch (error: any) {
      return res.status(500).json({
        connected: false,
        message: 'Unexpected error testing database connection',
        error: error.message || 'Unknown error',
      });
    }
  });

  // ==========================================
  // DYNAMIC SITEMAP (BACKGROUND REFRESH)
  // ==========================================
  let cachedSitemapXml: string | null = null;
  let refreshInProgress: Promise<string> | null = null;
  let sitemapIntervalId: NodeJS.Timeout | null = null;
  
  const SITEMAP_CACHE_PATH = process.env.SITEMAP_CACHE_PATH || path.join(process.cwd(), 'data', 'sitemap-cache.xml');

  // Attempt to load from disk cache on startup
  try {
    if (fs.existsSync(SITEMAP_CACHE_PATH)) {
      cachedSitemapXml = fs.readFileSync(SITEMAP_CACHE_PATH, 'utf-8');
      console.log('[Sitemap] Loaded from disk cache.');
    }
  } catch (err) {
    console.warn('[Sitemap] Failed to load disk cache:', err);
  }

  async function refreshSitemap() {
    if (refreshInProgress) return refreshInProgress;

    refreshInProgress = (async () => {
      const refreshTask = beginTrackedTask('refresh_sitemap', 'internal_task', { resource: 'background_job' });
      const startTime = Date.now();
      logEvent('info', 'sitemap_background_refresh_started');
      try {
        const posts = await fetchPosts();
        const xml = renderSitemap(posts);
        
        cachedSitemapXml = xml;
        
        // Try to save to disk asynchronously using atomic write
        fs.promises.mkdir(path.dirname(SITEMAP_CACHE_PATH), { recursive: true })
          .then(async () => {
            const tmpPath = `${SITEMAP_CACHE_PATH}.tmp`;
            await fs.promises.writeFile(tmpPath, xml, 'utf-8');
            await fs.promises.rename(tmpPath, SITEMAP_CACHE_PATH);
          })
          .catch(err => console.warn('[Sitemap] Failed to write disk cache:', err));
        
        const institutionalCount = publicRoutes.length;
        const wpCount = posts.length;
        const durationMs = Date.now() - startTime;
        logEvent('info', 'sitemap_background_refresh_succeeded', { institutionalCount, wpCount, totalUrls: institutionalCount + wpCount, durationMs });
        refreshTask.complete({ institutionalCount, wpCount, totalUrls: institutionalCount + wpCount, durationMs });
        return xml;
      } catch (err) {
        const durationMs = Date.now() - startTime;
        logEvent('error', 'sitemap_background_refresh_failed', { error: serializeError(err), durationMs });
        refreshTask.fail({ error: serializeError(err), durationMs });
        throw err;
      } finally {
        refreshInProgress = null;
      }
    })();

    return refreshInProgress;
  }

  const sitemapRefreshOnStart = process.env.SITEMAP_REFRESH_ON_START === 'true';
  if (sitemapRefreshOnStart || !cachedSitemapXml) {
    refreshSitemap().catch(() => {});
  }
  
  const sitemapRefreshIntervalMs = Number(process.env.SITEMAP_REFRESH_INTERVAL_MS) || 21600000;
  sitemapIntervalId = setInterval(() => {
    refreshSitemap().catch(() => {});
  }, sitemapRefreshIntervalMs);
  
  if (sitemapIntervalId && typeof sitemapIntervalId.unref === 'function') {
    sitemapIntervalId.unref();
  }

  const webhookRateLimit = new Map<string, number>();
  
  app.post('/internal/revalidate-sitemap', (req, res) => {
    const token = req.headers['authorization']?.replace('Bearer ', '');
    const validToken = process.env.SITEMAP_REVALIDATE_TOKEN;
    
    if (!validToken || token !== validToken) {
      logEvent('warn', 'revalidate_sitemap_unauthorized', { ip: req.ip });
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const now = Date.now();
    const lastCall = webhookRateLimit.get('revalidate') || 0;
    if (now - lastCall < 10000) { // 10 seconds rate limit
      return res.status(429).json({ error: 'Too many requests. Wait before trying again.' });
    }
    webhookRateLimit.set('revalidate', now);

    if (refreshInProgress) {
      return res.json({ success: true, message: 'Sitemap refresh already in progress' });
    }

    refreshSitemap()
      .then(() => res.json({ success: true, message: 'Sitemap revalidated' }))
      .catch((err) => {
        logEvent('error', 'revalidate_sitemap_failed', { error: serializeError(err) });
        res.status(500).json({ error: 'Failed to revalidate sitemap' });
      });
  });

  app.get('/healthz', (req, res) => {
    res.json({
      status: 'ok',
      uptime: process.uptime(),
      pid: process.pid,
      environment: process.env.NODE_ENV || 'development',
      sitemapCache: cachedSitemapXml ? 'available' : 'missing'
    });
  });

  app.get('/internal/runtime-status', (req, res) => {
    const token = req.headers['authorization']?.replace('Bearer ', '');
    const validToken = process.env.INTERNAL_STATUS_TOKEN || process.env.SITEMAP_REVALIDATE_TOKEN;
    
    if (!validToken || token !== validToken) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const memoryUsage = process.memoryUsage();
    res.json({
      status: 'ok',
      pid: process.pid,
      isShuttingDown: (global as any).__isShuttingDown || false,
      sitemapRefreshInProgress: !!refreshInProgress,
      crawlerLoggingEnabled: process.env.CRAWLER_LOGGING_ENABLED === 'true',
      observabilityEnabled: process.env.OBSERVABILITY_ENABLED === 'true',
      uptime: process.uptime(),
      memory: {
        rssMb: Math.round(memoryUsage.rss / 1024 / 1024),
        heapUsedMb: Math.round(memoryUsage.heapUsed / 1024 / 1024)
      }
    });
  });

  app.get('/sitemap.xml', (req, res) => {
    const request = createHttpTask(req, res, 'get_sitemap_xml'); const startTime = Date.now(); let error: unknown = null;
    try {
      if (!cachedSitemapXml) {
        const durationMs = Date.now() - startTime;
        logEvent('warn', 'sitemap_served_empty', { durationMs });
        res.header('Content-Type', 'application/xml; charset=utf-8');
        res.header('Retry-After', '60');
        return res.status(503).send('<?xml version="1.0" encoding="UTF-8"?><urlset></urlset>');
      }

      res.header('Content-Type', 'application/xml; charset=utf-8');
      res.header('Cache-Control', 'public, max-age=3600, stale-while-revalidate=86400');
      res.send(cachedSitemapXml);
      logEvent('info', 'sitemap_served_from_memory', { durationMs: Date.now() - startTime, userAgent: req.headers['user-agent'] || 'unknown' });
    } catch (err) { error = err; throw err; }
    finally { request.finish(error, { durationMs: Date.now() - startTime }); }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    // Only import Vite in development dynamically to prevent bundling in production
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production static serving
    const distPath = path.join(process.cwd(), 'dist');

  // Serve static files
  app.use(express.static(distPath, { extensions: ['html'], index: false }));
    
    // Serve prerendered routes if they exist, or fallback to index
    const knownRoutes = publicRoutes.map(route => route.replace(/\/$/, '') || '/');
    
    // In-memory cache for file existence to avoid blocking the event loop
    const fileExistenceCache = new Map<string, boolean>();

    app.use(async (req, res) => {
      const normalizedPath = req.path.replace(/\/$/, '') || '/';
      
      // 1. Check if it's a known prerendered route or a resource
      if (knownRoutes.includes(normalizedPath) || req.path.startsWith('/recursos/')) {
        const routeFolder = normalizedPath === '/' ? '' : normalizedPath;
        const prerenderedFile = path.join(distPath, routeFolder, 'index.html');
        
        let fileExists = fileExistenceCache.get(prerenderedFile);
        if (fileExists === undefined) {
          try {
            await fs.promises.access(prerenderedFile);
            fileExists = true;
          } catch {
            fileExists = false;
          }
          // Cache the result for production performance
          fileExistenceCache.set(prerenderedFile, fileExists);
        }
        
        if (fileExists) {
          return res.sendFile(prerenderedFile);
        }
        
        // Fallback to main index for SPA hydration if specific file not found
        return res.sendFile(path.join(distPath, 'index.html'));
      }
      
      // 2. Handle 404 for unknown routes
      res.status(404).sendFile(path.join(distPath, '404.html'), (err) => {
        if (err) res.status(404).sendFile(path.join(distPath, 'index.html'));
      });
    });
  }

  const server = app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`RAUVIA Server running on http://localhost:${PORT}`);
  });
  attachInboundHttpSocketTracking(server);

  const handleShutdown = async (signal: string) => {
    if ((global as any).__isShuttingDown) {
      console.log(`[Server] Already shutting down. Ignoring ${signal}.`);
      return;
    }
    (global as any).__isShuttingDown = true;
    console.log(`[Server] Received ${signal}. Shutting down gracefully...`);
    
    const forceExitTimer = setTimeout(() => {
      console.error('[Server] Graceful shutdown timed out after 10s. Forcing exit.');
      process.exit(1);
    }, 10000);
    forceExitTimer.unref();

    if (sitemapIntervalId) {
      clearInterval(sitemapIntervalId);
    }
    stopObservabilityTicker();
    
    // Aggressive socket cleanup for keep-alive issues
    if (server.closeIdleConnections) server.closeIdleConnections();
    setTimeout(() => {
      if (server.closeAllConnections) server.closeAllConnections();
    }, 2000).unref();
    destroyAllInboundHttpSockets();

    try {
      await closeDbPool();
      console.log('[Server] DB pool closed.');
    } catch (err) {
      console.error('[Server] Error closing DB pool:', err);
    }

    server.close(() => {
      console.log('[Server] HTTP server closed.');
      clearTimeout(forceExitTimer);
      process.exit(signal === 'FATAL_ERROR' ? 1 : 0);
    });
  };

  // Register shutdown handlers
  process.on('SIGTERM', () => handleShutdown('SIGTERM'));
  process.on('SIGINT', () => handleShutdown('SIGINT'));
  process.on('uncaughtException', (err) => {
    console.error('[Server] Uncaught Exception:', err);
    handleShutdown('FATAL_ERROR');
  });
  process.on('unhandledRejection', (reason) => {
    console.error('[Server] Unhandled Rejection:', reason);
    handleShutdown('FATAL_ERROR');
  });
}

console.log(`[Server] Starting process. PID: ${process.pid}, ENV: ${process.env.NODE_ENV || 'development'}`);
startServer();
