// Canonical routes shared by sitemap, prerender and production fallback.
export const publicRoutes = [
  '/', '/nosotros', '/soluciones', '/aethryon', '/recursos',
  '/frente-comercial', '/sitio-web-comercial-para-pymes', '/casos', '/casos/infraestructura-temporal-b2b',
  '/aviso-de-privacidad', '/terminos',
];
