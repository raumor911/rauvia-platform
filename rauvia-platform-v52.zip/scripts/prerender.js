import puppeteer from 'puppeteer';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import express from 'express';
import { publicRoutes } from './public-routes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootPath = path.resolve(__dirname, '..');
const distPath = path.join(rootPath, 'dist');

const routes = [...publicRoutes, '/404'];

async function startServer() {
  const app = express();
  // Keep the clean Vite shell in memory. Reusing the already-rendered home
  // would leak its canonical/title into every following prerendered page.
  const shell = await fs.readFile(path.join(distPath, 'index.html'), 'utf8');
  
  app.get('/api/wp/posts', async (req, res) => {
    try {
      const slug = req.query.slug;
      const wpBase = process.env.VITE_WORDPRESS_API_URL || 'https://blog.rauvia.com.mx/wp-json/wp/v2';
      const cacheBuster = `_cb=${Date.now()}`;
      const wpUrl = slug
        ? `${wpBase}/posts?slug=${encodeURIComponent(slug)}&_embed&status=publish&${cacheBuster}`
        : `${wpBase}/posts?_embed&status=publish&${cacheBuster}`;

      console.log(`[prerender] Fetching: ${wpUrl}`);
      const wpRes = await fetch(wpUrl, { signal: AbortSignal.timeout(10000) });
      if (!wpRes.ok) {
        console.error(`[prerender] Fetch failed: ${wpRes.status} ${wpRes.statusText}`);
        return res.status(wpRes.status).json([]);
      }
      const data = await wpRes.json();
      console.log(`[prerender] Fetched ${data.length} posts successfully.`);
      res.json(data);
    } catch (e) {
      console.error(`[prerender] Exception: ${e.message}`);
      res.status(500).json([]);
    }
  });

  app.get(routes, (_req, res) => res.type('html').send(shell));
  app.use(express.static(distPath));
  
  app.get('/{*splat}', (req, res) => {
    res.type('html').send(shell);
  });

  return new Promise((resolve) => {
    const server = app.listen(0, () => resolve(server));
  });
}

async function prerender() {
  console.log('Starting prerender process...');
  const server = await startServer();
  const port = server.address().port;
  const baseUrl = `http://localhost:${port}`;

  const browser = await puppeteer.launch({
    headless: 'new',
    args: ['--no-sandbox', '--disable-setuid-sandbox']
  });

  for (const route of routes) {
    console.log(`Prerendering ${route}...`);
    const page = await browser.newPage();
    await page.goto(`${baseUrl}${route}`, { waitUntil: 'networkidle0' });
    
    // Get HTML content
    const html = await page.content();
    const canonical = await page.locator('link[rel="canonical"]').waitHandle();
    const canonicalUrls = await page.$$eval('link[rel="canonical"]', links => links.map(link => link.href));
    await canonical.dispose();
    
    const expectedCanonical = (route === '/') 
      ? `https://rauvia.com.mx${route}`
      : `https://rauvia.com.mx${route}/`;

    if (canonicalUrls.length !== 1 || canonicalUrls[0] !== expectedCanonical) {
      throw new Error(`Canonical inválido en ${route}: ${canonicalUrls.join(', ')} (Esperado: ${expectedCanonical})`);
    }
    
    // Save to dist
    const filePath = route === '/' 
      ? path.join(distPath, 'index.html') 
      : route === '/404'
        ? path.join(distPath, '404.html')
        : path.join(distPath, route, 'index.html');
        
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, html);
    await page.close();
  }

  await browser.close();
  server.close();
  console.log('Prerender complete.');
}

prerender().catch(err => {
  console.error('Prerender failed:', err);
  process.exit(1);
});
