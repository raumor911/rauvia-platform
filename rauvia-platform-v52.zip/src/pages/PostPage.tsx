import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import SEO from '../components/SEO';
import JsonLd from '../components/JsonLd';
import { getPostBySlug, WPPost } from '../lib/wp';
import FadeInUp from '../components/FadeInUp';
import RauviaEditorial, { sanitizeTitleHtml } from '../components/RauviaEditorial';

export default function PostPage() {
  const { slug } = useParams<{ slug: string }>();
  const [post, setPost] = useState<WPPost | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setLoadError(false);
    setPost(null);
    if (!slug) {
      setLoading(false);
      return;
    }
    getPostBySlug(slug)
      .then(data => { if (active) setPost(data); })
      .catch(() => { if (active) setLoadError(true); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [slug]);

  if (loading) {
    return (
      <section className="pt-32 pb-24 px-4 bg-rauvia-bg min-h-screen">
        <div className="max-w-3xl mx-auto animate-pulse">
          <div className="h-8 bg-rauvia-card w-1/4 rounded mb-8"></div>
          <div className="h-12 bg-rauvia-card w-full rounded mb-6"></div>
          <div className="h-4 bg-rauvia-card w-1/3 rounded mb-12"></div>
          <div className="space-y-4">
            <div className="h-4 bg-rauvia-card w-full rounded"></div>
            <div className="h-4 bg-rauvia-card w-full rounded"></div>
            <div className="h-4 bg-rauvia-card w-5/6 rounded"></div>
          </div>
        </div>
      </section>
    );
  }

  if (!post) {
    return (
      <section className="pt-32 pb-24 px-4 bg-rauvia-bg min-h-screen">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-3xl font-display text-rauvia-text mb-6">{loadError ? 'No pudimos cargar el artículo' : 'Artículo no encontrado'}</h1>
          <p className="text-rauvia-gray mb-8">{loadError ? 'Intenta volver a abrirlo en unos momentos.' : 'El recurso que buscas no existe o ha sido movido.'}</p>
          <Link to="/recursos" className="inline-flex items-center gap-2 text-rauvia-accent hover:text-rauvia-accent/80 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span>Volver a recursos</span>
          </Link>
        </div>
      </section>
    );
  }

  const cleanExcerpt = post.excerpt.rendered.replace(/<[^>]*>?/gm, '').trim();
  const featuredMedia = post._embedded?.['wp:featuredmedia']?.[0]?.source_url;
  const authorName = post._embedded?.author?.[0]?.name || 'Raúl Morales';
  const authorUrl = "https://rauvia.com.mx/nosotros";
  const postUrl = `https://rauvia.com.mx/recursos/${post.slug}`;

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    "mainEntityOfPage": {
      "@type": "WebPage",
      "@id": `${postUrl}/#webpage`
    },
    "headline": post.title.rendered.replace(/<[^>]*>?/gm, ''),
    "description": cleanExcerpt,
    "image": featuredMedia || "https://rauvia.com.mx/media/article-cover.jpg",
    "author": {
      "@type": "Person",
      ...(authorName === 'Raúl Morales' ? { "@id": "https://rauvia.com.mx/#raul-morales" } : {}),
      "name": authorName,
      "url": authorUrl
    },
    "publisher": {
      "@id": "https://rauvia.com.mx/#organization"
    },
    "datePublished": post.date,
    "dateModified": post.modified
  };

  return (
    <>
      <SEO 
        title={`${post.title.rendered.replace(/<[^>]*>?/gm, '')} | RAUVIA`}
        description={cleanExcerpt}
        canonicalUrl={postUrl}
      />
      <JsonLd data={structuredData} />

      <article className="rauvia-post-page min-h-screen">
        <div className="rauvia-post-shell">
          <FadeInUp>
            <Link to="/recursos" className="inline-flex items-center gap-2 text-rauvia-gray hover:text-rauvia-accent transition-colors mb-8 text-sm">
              <ArrowLeft className="w-4 h-4" />
              <span>Todos los recursos</span>
            </Link>
            
            <header className="rauvia-post-header">
              <h1 
                className="text-4xl md:text-5xl font-display text-rauvia-text mb-6 leading-tight"
                dangerouslySetInnerHTML={{ __html: sanitizeTitleHtml(post.title.rendered) }}
              />
              
              <div className="rauvia-post-meta text-sm text-rauvia-gray pb-8 border-b border-rauvia-border/50">
                <span className="font-medium">{authorName}</span>
                <span>•</span>
                <time dateTime={post.date}>
                  {new Date(post.date).toLocaleDateString('es-MX', { year: 'numeric', month: 'long', day: 'numeric' })}
                </time>
              </div>
            </header>
          </FadeInUp>

          <div>
            {/* CONTENIDO EDITORIAL */}
            <div>
              {featuredMedia && (
                <FadeInUp delay={0.1}>
                  <div className="rauvia-post-cover">
                    <img 
                      src={featuredMedia} 
                      alt={post.title.rendered.replace(/<[^>]*>?/gm, '')} 
                      className="w-full h-auto"
                    />
                  </div>
                </FadeInUp>
              )}
              
              <RauviaEditorial htmlContent={post.content.rendered} articleTitle={post.title.rendered} />
            </div>
            
            {/* CTA AL FINAL */}
            <FadeInUp delay={0.3}>
              <div className="mt-16 max-w-2xl mx-auto bg-white border border-slate-200 rounded-xl p-8 md:p-12 shadow-sm flex flex-col items-center text-center">
                <div className="w-16 h-16 bg-rauvia-navy rounded-2xl mb-6 flex items-center justify-center">
                  <img src="/media/iconos-enfoques-rauvia/05-aethryon.svg" alt="AETHRYON" className="w-8 h-8" />
                </div>
                <h3 className="text-lg md:text-xl font-bold tracking-widest text-slate-400 uppercase mb-4">¿Necesitas acelerar este proceso?</h3>
                <p className="text-base md:text-lg text-slate-600 mb-8 leading-relaxed max-w-lg">
                  AETHRYON es nuestro sistema de análisis que identifica restricciones operativas y diseña rutas de ejecución.
                </p>
                <Link to="/aethryon" className="block w-full sm:w-auto px-8 bg-rauvia-navy text-white text-center py-4 rounded-lg text-sm md:text-base font-bold hover:bg-rauvia-blue transition-colors">
                  Conocer AETHRYON
                </Link>
              </div>
            </FadeInUp>
          </div>
        </div>
      </article>

      
    </>
  );
}
