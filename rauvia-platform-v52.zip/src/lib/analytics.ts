import { getVisitorId, getSessionId, updateSessionActivity } from './analyticsIdentity';

export type EventName =
  | 'page_view'
  | 'case_view'
  | 'solution_view'
  | 'aethryon_view'
  | 'blog_view'
  | 'cta_click'
  | 'whatsapp_click'
  | 'assistant_open'
  | 'assistant_start'
  | 'assistant_question'
  | 'assistant_response'
  | 'assistant_summary_generated';

interface TrackEventParams {
  eventName: EventName;
  properties?: Record<string, any>;
  pagePath?: string;
  referrer?: string;
}

const API_ENDPOINT = '/api/events';

export function trackEvent(
  eventName: EventName,
  properties?: Record<string, any>
): void {
  try {
    const visitorId = getVisitorId();
    const sessionId = getSessionId();

    const isMobile = /Mobi|Android/i.test(navigator.userAgent);
    const isTablet = /Tablet|iPad/i.test(navigator.userAgent);
    const deviceType = isTablet ? 'tablet' : isMobile ? 'mobile' : 'desktop';

    const payload = {
      visitor_id: visitorId,
      session_id: sessionId,
      event_name: eventName,
      page_path: window.location.pathname + window.location.search,
      referrer: document.referrer || '',
      device_type: deviceType,
      properties: properties || {},
    };

    // Update last activity since we're tracking a valid event
    updateSessionActivity();

    // Use sendBeacon if available for better non-blocking performance
    if (navigator.sendBeacon) {
      const blob = new Blob([JSON.stringify(payload)], { type: 'application/json' });
      navigator.sendBeacon(API_ENDPOINT, blob);
    } else {
      fetch(API_ENDPOINT, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
        keepalive: true,
      }).catch(() => {
        // Silently catch network errors so UI doesn't break
      });
    }
  } catch (err) {
    // Fail silently in production
    if (process.env.NODE_ENV === 'development') {
      console.error('[Analytics] Failed to track event:', err);
    }
  }
}
