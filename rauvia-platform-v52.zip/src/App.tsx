import React from 'react';
import { HelmetProvider } from 'react-helmet-async';
import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import NosotrosPage from './pages/NosotrosPage';
import SolucionesPage from './pages/SolucionesPage';
import AethryonPage from './pages/AethryonPage';
import RecursosPage from './pages/RecursosPage';
import PostPage from './pages/PostPage';
import NotFoundPage from './pages/NotFoundPage';
import AvisoPrivacidadPage from './pages/AvisoPrivacidadPage';
import TerminosPage from './pages/TerminosPage';
import FrenteComercialPage from './pages/FrenteComercialPage';
import SitioWebComercialPymesPage from './pages/SitioWebComercialPymesPage';
import CasosIndexPage from './pages/CasosIndexPage';
import CasoInfraestructuraB2BPage from './pages/CasoInfraestructuraB2BPage';
import { GeoProvider } from './context/GeoContext';
import GeoBanner from './components/GeoBanner';
import TrackingRouteObserver from './components/TrackingRouteObserver';
import AIAssistantWidget from './components/AIAssistantWidget';

// Component to scroll to top on route change
function ScrollToTop() {
  const { pathname, hash } = useLocation();

  React.useEffect(() => {
    if (hash) {
      setTimeout(() => {
        const id = hash.replace('#', '');
        const element = document.getElementById(id);
        if (element) {
          element.scrollIntoView({ behavior: 'smooth' });
        }
      }, 100);
    } else {
      window.scrollTo(0, 0);
    }
  }, [pathname, hash]);

  return null;
}

export default function App() {
  return (
    <GeoProvider>
      <HelmetProvider>
        <BrowserRouter>
          <TrackingRouteObserver />
          <ScrollToTop />
          <AIAssistantWidget />
          <div className="min-h-screen bg-rauvia-bg">
            <Navbar />
            
            <main>
              <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/nosotros" element={<NosotrosPage />} />
                <Route path="/soluciones" element={<SolucionesPage />} />
                <Route path="/aethryon" element={<AethryonPage />} />
                <Route path="/recursos" element={<RecursosPage />} />
                <Route path="/recursos/:slug" element={<PostPage />} />
                <Route path="/aviso-de-privacidad" element={<AvisoPrivacidadPage />} />
                <Route path="/terminos" element={<TerminosPage />} />
                <Route path="/frente-comercial" element={<FrenteComercialPage />} />
                <Route path="/sitio-web-comercial-para-pymes" element={<SitioWebComercialPymesPage />} />
                <Route path="/casos" element={<CasosIndexPage />} />
                <Route path="/casos/infraestructura-temporal-b2b" element={<CasoInfraestructuraB2BPage />} />
                <Route path="*" element={<NotFoundPage />} />
              </Routes>
            </main>
            <Footer />
          </div>
          <GeoBanner />
        </BrowserRouter>
      </HelmetProvider>
    </GeoProvider>
  );
}
